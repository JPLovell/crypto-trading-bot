# Crypto Arbitrage Bot (Paper Mode v3)

An autonomous crypto arbitrage trading bot designed to run 24/7 on Render's free tier.

## Configuration & Multi-Pair Support (v3)
- **Initial Deposit**: £50.00
- **Minimum Spread Threshold**: 0.30%
- **Estimated Fee Coverage**: 0.20% round-trip
- **Monitored Pairs**:
  - BTC/USDT vs BTC/USDC
  - ETH/USDT vs ETH/USDC
  - SOL/USDT vs SOL/USDC

## Deployment Instructions

1. **GitHub**:
   - Create a new repository on GitHub.
   - Upload all extracted files in this repository.

2. **Render**:
   - Sign in to Render and create a new **Web Service**.
   - Select your GitHub repository.
   - Render automatically reads `render.yaml` to build and deploy the web dashboard.

3. **24/7 Keep-Alive (UptimeRobot)**:
   - Create a free UptimeRobot account.
   - Add an HTTP monitor to ping your Render URL every 10 minutes to prevent sleeping.
