import os

# Trading Configuration
STARTING_BALANCE = 50.0  # £50 initial paper trading balance
CURRENCY_SYMBOL = "£"
COMPOUND_TRADES = True   # Reinvest full balance on each trade

# Minimum spread percentage required after accounting for fees
# 0.30% ensures fee coverage (~0.20% round-trip) + net profit margin (~0.10%)
MIN_SPREAD_PCT = 0.30
ESTIMATED_FEE_PCT = 0.20  # Total round-trip exchange fees (0.10% buy + 0.10% sell)

# Monitored Trading Pairs across major liquid markets
TRADING_PAIRS = [
    ("BTC/USDT", "BTC/USDC"),
    ("ETH/USDT", "ETH/USDC"),
    ("SOL/USDT", "SOL/USDC"),
]

# Web Dashboard Server Config
PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
