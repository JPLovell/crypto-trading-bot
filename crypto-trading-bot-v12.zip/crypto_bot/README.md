# Autonomous Crypto Trading Bot (v12 Kraken Pro Architecture)

## Overview
- **Exchange:** Kraken Pro (Fully Authorized & Open to New UK Retail Residents)
- **UK Fiat Support:** Native GBP deposits and withdrawals via UK Faster Payments (£0 fee)
- **Fee Model:** Kraken Pro standard retail taker tier (0.40% buy + 0.40% sell = 0.80% round-trip)
- **Spread Gate:** Strict >= 0.88% minimum spread required before order trigger (guarantees net profit)
- **Trade Sizing:** Dynamic £10.00 – £25.00 sizing cap (retains >= 50% cash buffer)
- **Order Safety:** Immediate-or-Cancel (IOC) order filtering + $50+ order book depth verification
- **Pair Universe:** 30 high-opportunity Kraken markets (including 15 direct GBP pairs)

## Why Kraken Pro for the UK?
1. **Fully Available:** Unlike Binance, Kraken is actively onboarding and verifying new UK residents.
2. **Direct GBP Trading:** 15 monitored pairs trade directly against British Pounds (BTC/GBP, ETH/GBP, SOL/GBP, etc.), eliminating USD conversion fees.
3. **Wider Altcoin Spreads:** Less institutional HFT crowding on Kraken allows 0.90%–1.45% spreads to linger 20ms–40ms, providing clean, high-margin capture opportunities.

## Deploying to Render
1. Extract `crypto-trading-bot-v12.zip`.
2. Commit and push the files to your GitHub repository.
3. Render will automatically detect the commit, build the dependencies, and launch your Kraken Pro Bot Dashboard.
