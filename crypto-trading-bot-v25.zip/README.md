# Crypto Trading Bot (v25 Dual-Slot Zero-Slippage Engine)

### Key Features:
- **Max 2 Concurrent Trade Slots (`MAX_CONCURRENT_TRADES = 2`)**: Opens up to 2 simultaneous trade positions across monitored pairs while maintaining a cash buffer.
- **£10.00 – £12.00 Flexible Trade Cap**: Dynamically sizes trades between £10.00 and £12.00 depending on available liquid cash balance.
- **Kraken Post-Only Limit Execution (`oflags=post`)**: Uses `ordertype='limit'` and `oflags='post'` to guarantee Maker status and zero slippage on all orders.
- **Top Bid Limit Entry**: Places limit buy orders at top bid price (`bid_price`) so orders enter the order book directly as Maker liquidity.
- **Order Book Depth Filter (£50+ Buffer)**: Verifies order book depth before trading to eliminate price impact.
- **Automatic Position Sync**: Automatically checks live wallet balances and clears trade memory slots if positions are manually converted or sold on Kraken.
- **+1.20% Net Profit Target Gate**: Holds positions until price reaches target margin above entry price.
