# ⚡ Autonomous Crypto Arbitrage Bot (Realistic Paper Trader v7)

An autonomous cryptocurrency arbitrage trading bot and live web dashboard built with Python, Flask, CCXT, and Render.

## Features in Version 7 (Realistic Testing):
- **Fixed Trade Sizing Cap**: Limits trade size to **£50.00 max** per order, preventing unrealistic runaway exponential compounding.
- **Multi-Exchange CCXT Live APIs**: Connects to public APIs across **Binance**, **Kraken**, and **Coinbase**.
- **Execution Latency Simulation**: Includes a **200ms network execution buffer** to simulate real-world order book speed checks.
- **Round-Trip Fee Deduction**: Automatically deducts **0.20% exchange taker fees** before recording net profit.
- **24/7 Autopilot Deployment**: Runs continuously on Render with UptimeRobot health check support.

## Deployment Instructions:
1. Upload `crypto-trading-bot-v7.zip` to your GitHub repository.
2. In Render Settings, set Build Command:
   `unzip -o crypto-trading-bot-v7.zip && cp -r crypto_bot/* . && pip install -r requirements.txt`
3. Click "Manual Deploy" -> "Deploy latest commit".
