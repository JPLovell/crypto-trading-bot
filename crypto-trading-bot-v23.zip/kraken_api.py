import time, requests, urllib.parse, hashlib, hmac, base64, threading

API_HOST = "api.kraken.com"
API_URL = "https://" + API_HOST

_nonce_lock = threading.Lock()
_last_nonce = 0

def get_nonce():
    global _last_nonce
    with _nonce_lock:
        now_micro = int(time.time() * 1000000)
        if now_micro <= _last_nonce:
            now_micro = _last_nonce + 1
        _last_nonce = now_micro
        return str(now_micro)

def get_kraken_signature(urlpath, data, secret):
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode('utf-8')
    message = urlpath.encode('utf-8') + hashlib.sha256(encoded).digest()
    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    return base64.b64encode(mac.digest()).decode('utf-8')

def kraken_request(uri_path, data, api_key, api_secret):
    if not api_key or not api_secret:
        return {"error": ["Missing API credentials"]}
    headers = {
        'API-Key': api_key.strip(),
        'API-Sign': get_kraken_signature(uri_path, data, api_secret.strip()),
        'User-Agent': 'Kraken Live Bot v23'
    }
    try:
        res = requests.post(API_URL + uri_path, headers=headers, data=data, timeout=8.0)
        return res.json()
    except Exception as e:
        return {"error": [str(e)]}

def get_ticker(symbol):
    """Fetch public ticker data (ask, bid, last) for a pair."""
    try:
        url = f"{API_URL}/0/public/Ticker?pair={symbol}"
        res = requests.get(url, timeout=5.0)
        data = res.json()
        if data.get('error'):
            return None, ", ".join(data['error'])
        result = data.get('result', {})
        for pair_key, val in result.items():
            ask = float(val['a'][0])
            bid = float(val['b'][0])
            last = float(val['c'][0])
            return {'ask': ask, 'bid': bid, 'last': last}, None
        return None, "Pair not found"
    except Exception as e:
        return None, str(e)

def get_order_book(symbol, count=10):
    """Inspect top order book depth to ensure adequate liquidity before trading."""
    try:
        url = f"{API_URL}/0/public/Depth?pair={symbol}&count={count}"
        res = requests.get(url, timeout=5.0)
        data = res.json()
        if data.get('error'):
            return None, ", ".join(data['error'])
        result = data.get('result', {})
        for pair_key, val in result.items():
            asks = val.get('asks', [])
            bids = val.get('bids', [])
            ask_depth_gbp = sum(float(a[0]) * float(a[1]) for a in asks)
            bid_depth_gbp = sum(float(b[0]) * float(b[1]) for b in bids)
            return {
                'ask_depth_gbp': ask_depth_gbp,
                'bid_depth_gbp': bid_depth_gbp,
                'top_ask': float(asks[0][0]) if asks else 0.0,
                'top_bid': float(bids[0][0]) if bids else 0.0
            }, None
        return None, "Order book pair not found"
    except Exception as e:
        return None, str(e)

def query_balances(api_key, api_secret):
    if not api_key or not api_secret:
        return None, "API keys missing"
    data = {'nonce': get_nonce()}
    res = kraken_request('/0/private/Balance', data, api_key, api_secret)
    if res.get('error'):
        return None, ", ".join(res['error'])
    return res.get('result', {}), None

def place_live_order(symbol, side, volume, api_key, api_secret, ordertype="limit", price=None, oflags="post-only"):
    data = {
        'nonce': get_nonce(),
        'pair': symbol,
        'type': side,
        'ordertype': ordertype,
        'volume': str(volume)
    }
    if price is not None:
        data['price'] = str(price)
    if oflags:
        data['oflags'] = oflags
    res = kraken_request('/0/private/AddOrder', data, api_key, api_secret)
    if res.get('error') and len(res['error']) > 0:
        return None, ", ".join(res['error'])
    result = res.get('result', {})
    txid = result.get('txid', ['UNKNOWN'])[0]
    return txid, None
