import os

# Account & Capital Settings
STARTING_BALANCE = 50.0          # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size threshold
MAX_TRADE_SIZE = 10.0            # £10 fixed trade size cap (preserves cash buffer)
MAX_WORKING_CAPITAL = 50.0       # Risk Ring-Fence Cap (£50 max active capital)
CURRENCY_SYMBOL = "£"

# Zero-Slippage & Limit Order Settings
EXECUTION_MODE = "Limit (Post-Only Zero Slippage)"
MIN_ORDERBOOK_DEPTH_GBP = 50.0   # £50 minimum top-of-book depth required
POST_ONLY_ENABLED = True         # Guarantees Maker execution (zero slippage)
MAKER_FEE_PCT = 0.25             # Kraken Pro maker fee tier (0.25%)
ROUNDTRIP_MAKER_FEE_PCT = 0.50   # Round-trip maker fee (0.50% vs 0.80% taker)
MIN_PROFIT_GATE_PCT = 1.20       # Minimum net profit gate (+1.20%)
COOLDOWN_SEC = 90                # Minimum 90s cooldown between buy orders to prevent over-trading

# Live Environment Variables & API Credentials
KRAKEN_API_KEY = os.environ.get("KRAKEN_API_KEY", "").strip()
KRAKEN_API_SECRET = os.environ.get("KRAKEN_API_SECRET", "").strip()
LIVE_TRADING_ENABLED = os.environ.get("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1", "yes"]

# Monitored Kraken Direct GBP Markets
MONITORED_PAIRS = [
    "BTC/GBP", "ETH/GBP", "SOL/GBP", "XRP/GBP", "ADA/GBP", 
    "DOT/GBP", "LINK/GBP", "AVAX/GBP", "NEAR/GBP", "DOGE/GBP",
    "LTC/GBP", "ATOM/GBP", "FIL/GBP", "UNI/GBP"
]

# Kraken API Symbol Translation Map
SYMBOL_MAP = {
    "BTC/GBP": "XBTGBP", "ETH/GBP": "ETHGBP", "SOL/GBP": "SOLGBP",
    "XRP/GBP": "XRPGBP", "ADA/GBP": "ADAGBP", "DOT/GBP": "DOTGBP",
    "LINK/GBP": "LINKGBP", "AVAX/GBP": "AVAXGBP", "NEAR/GBP": "NEARGBP",
    "DOGE/GBP": "DOGEGBP", "LTC/GBP": "LTCGBP", "ATOM/GBP": "ATOMGBP",
    "FIL/GBP": "FILGBP", "UNI/GBP": "UNIGBP"
}

PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
