# Crypto Trading Bot (v23 Zero-Slippage Limit Engine)

Autonomous Kraken Pro trading bot with Post-Only limit order execution, £10 fixed trade cap, £50+ order book depth buffer, and +1.20% net profit target gates.

## Key Features in v23:
- **Zero-Slippage Limit Orders:** All buys and sells execute as  with .
- **Post-Only Maker Guarantee:** Prevents orders from taking liquidity or incurring high taker fees.
- **Order Book Depth Filter:** Inspects top order book depth to enforce a minimum £50.00 liquidity buffer before placing trades.
- **Fixed £10.00 Position Cap:** Preserves ~75% of capital in liquid GBP cash while trading with small, safe position sizes.
- **+1.20% Net Profit Gate:** Locks open crypto positions until market prices reach target gains above entry.
