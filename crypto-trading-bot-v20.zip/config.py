import os

# Account & Capital Settings
STARTING_BALANCE = 50.0          # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size
MAX_TRADE_SIZE = 25.0            # £25 max trade size cap
MAX_WORKING_CAPITAL = 50.0       # Risk Ring-Fence Cap (£50 max active capital)
CURRENCY_SYMBOL = "£"

# Kraken Pro Fee & Execution Parameters
PRIMARY_EXCHANGE = "Kraken Pro"
TAKER_FEE_PCT = 0.40             # Kraken Pro standard entry taker fee per trade (0.40%)
ROUNDTRIP_FEE_PCT = 0.80         # Round-trip buy taker + sell taker fee (0.80%)
MIN_SPREAD_THRESHOLD = 0.88      # Minimum spread required to trigger order (0.88%)
MIN_DEPTH_USD = 50.0             # $50 top-of-book depth filter
LATENCY_BUFFER_MS = 25           # WebSocket execution latency buffer (25ms)

# Automated Round-Trip Exit & Auto-Conversion Settings
AUTO_CONVERT_TO_GBP = True       # Automatically convert all crypto holdings back to GBP
PROFIT_TARGET_PCT = 0.50         # Auto-sell target profit (+0.50% net above entry)
MAX_HOLD_TIME_SEC = 120          # Max position hold time before auto-closing to GBP (2 minutes)

# Live Environment Variables & API Credentials
KRAKEN_API_KEY = os.environ.get("KRAKEN_API_KEY", "").strip()
KRAKEN_API_SECRET = os.environ.get("KRAKEN_API_SECRET", "").strip()
LIVE_TRADING_ENABLED = os.environ.get("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1", "yes"]

# 30 Kraken Markets Monitored
MONITORED_PAIRS = [
    "BTC/GBP", "ETH/GBP", "SOL/GBP", "XRP/GBP", "ADA/GBP", 
    "DOT/GBP", "LINK/GBP", "AVAX/GBP", "NEAR/GBP", "DOGE/GBP",
    "LTC/GBP", "ATOM/GBP", "FIL/GBP", "UNI/GBP", "USDT/GBP",
    "NEAR/USDT", "SOL/USDT", "FIL/USDT", "UNI/USDT", "INJ/USDT",
    "TIA/USDT", "RENDER/USDT", "SUI/USDT", "PEPE/USDT", "FET/USDT",
    "ARB/USDT", "OP/USDT", "DOT/USDT", "LINK/USDT", "BTC/USDT"
]

# Kraken API Symbol Translation Map
SYMBOL_MAP = {
    "BTC/GBP": "XBTGBP", "ETH/GBP": "ETHGBP", "SOL/GBP": "SOLGBP",
    "XRP/GBP": "XRPGBP", "ADA/GBP": "ADAGBP", "DOT/GBP": "DOTGBP",
    "LINK/GBP": "LINKGBP", "AVAX/GBP": "AVAXGBP", "NEAR/GBP": "NEARGBP",
    "DOGE/GBP": "DOGEGBP", "LTC/GBP": "LTCGBP", "ATOM/GBP": "ATOMGBP",
    "FIL/GBP": "FILGBP", "UNI/GBP": "UNIGBP", "USDT/GBP": "USDTGBP"
}

PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
