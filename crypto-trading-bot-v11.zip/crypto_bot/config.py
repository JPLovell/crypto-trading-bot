import os

# Account & Capital Settings (Single-Exchange Architecture)
STARTING_BALANCE = 50.0          # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size (comfortably clears Binance $5-$10 min order)
MAX_TRADE_SIZE = 25.0            # £25 max trade size cap (preserves >= 50% cash liquidity reserve)
CURRENCY_SYMBOL = "£"

# Single-Exchange Execution Parameters (Binance Intra-Market)
PRIMARY_EXCHANGE = "Binance"
STANDARD_FEE_PCT = 0.10          # Binance standard spot fee per trade (0.10%)
ROUNDTRIP_FEE_PCT = 0.20         # Round-trip buy + sell fee (0.20%)
BNB_DISCOUNT_FEE_PCT = 0.075     # Optional BNB discounted fee (0.075%)
MIN_SPREAD_THRESHOLD = 0.28      # Minimum spread required to trigger order (0.28%)
MIN_DEPTH_USD = 50.0             # $50 top-of-book depth filter to guarantee zero slippage
LATENCY_BUFFER_MS = 25           # Realistic WebSocket event execution latency (25ms)

# Live Market Reality Settings (Simulated HFT Competition & Fill Modeling)
SIMULATE_REALISTIC_FILLS = True
FILL_RATE_MEGA_CAP = 0.22        # ~22% fill rate on BTC, ETH, SOL (high HFT competition)
FILL_RATE_VOLATILE_ALT = 0.58    # ~58% fill rate on mid-cap alts (retail volatility lingers longer)
FILL_RATE_STABLECOIN = 0.35      # ~35% fill rate on stablecoin order books

# 30 High-Volume Binance Markets Monitored Simultaneously
MONITORED_PAIRS = [
    # Top Tier Layer-1 & Mega-Caps (High HFT Competition)
    "BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT", 
    "ADA/USDT", "AVAX/USDT", "DOT/USDT", "NEAR/USDT", "SUI/USDT",
    # High-Momentum Alts & DeFi (Highest Real-World Fill Rates)
    "LINK/USDT", "DOGE/USDT", "PEPE/USDT", "SHIB/USDT", "LTC/USDT",
    "ARB/USDT", "OP/USDT", "INJ/USDT", "TIA/USDT", "FET/USDT",
    "RENDER/USDT", "ATOM/USDT", "UNI/USDT", "APT/USDT", "FIL/USDT",
    "ICP/USDT", "FTM/USDT",
    # Cross-Stablecoin Order Books (USDT vs USDC on Binance)
    "BTC/USDC", "ETH/USDC", "SOL/USDC"
]

# Web Server & Deployment Settings
PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
