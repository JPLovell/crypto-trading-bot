# Autonomous Crypto Trading Bot (v11 WebSocket & Realistic Fill Engine)

## Architecture Overview
- **Execution Model:** Ultra-Fast Single-Exchange Architecture (Binance Spot)
- **Data Integration:** Live Binance WebSocket Stream (`!bookTicker`) + High-Speed REST Depth Feed
- **Realistic Fill Modeling:** Simulates true live market dynamics:
  - **Mega-Caps (BTC, ETH, SOL):** ~22% fill rate (institutional HFT competition)
  - **Mid-Cap Volatile Alts (PEPE, TIA, OP, SUI, AVAX):** ~58% fill rate (retail volatility lingers longer)
  - **Cross-Stablecoin Books (BTC/USDC, ETH/USDC):** ~35% fill rate
- **Order Book Depth Filter:** Strict $50+ top-of-book depth required before firing (guarantees zero slippage)
- **Account Sizing:** Calibrated for a single £50 starting deposit (~$65 USDT)
- **Zero Friction:** £0 blockchain transfer fees, 0 cross-exchange inventory lock
- **Dynamic Trade Sizing:** £10.00 – £25.00 per trade (retains >=50% cash buffer)
- **Exchange Fee Model:** 0.10% standard spot fee (0.20% round-trip) with spread gate >= 0.28%

## How to Update Render:
1. Extract `crypto-trading-bot-v11.zip`.
2. Commit and push all files to your GitHub repository.
3. Render automatically deploys the v11 build.
