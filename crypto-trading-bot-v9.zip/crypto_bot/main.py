import time
import os
import threading
import random
import requests
from flask import Flask, render_template_string, jsonify
import config

app = Flask(__name__)

state = {
    'balance': config.STARTING_BALANCE,
    'initial_balance': config.STARTING_BALANCE,
    'trades': [],
    'logs': [],
    'status': 'RUNNING (v9 DYNAMIC SIZING)',
    'last_check': None,
    'exchanges': config.EXCHANGES,
    'monitored_pairs': config.TRADING_PAIRS
}

def add_log(msg):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    entry = f'[{timestamp}] {msg}'
    state['logs'].append(entry)
    if len(state['logs']) > 100:
        state['logs'].pop(0)

HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Crypto Arbitrage Bot Dashboard (v9 Dynamic Sizing)</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 20px; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .card { background: #1e293b; padding: 18px; border-radius: 10px; border: 1px solid #334155; }
        .card h3 { margin: 0 0 8px 0; color: #94a3b8; font-size: 13px; text-transform: uppercase; }
        .card .value { font-size: 22px; font-weight: bold; color: #38bdf8; }
        .green { color: #4ade80 !important; }
        .red { color: #f87171 !important; }
        table { width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 10px; overflow: hidden; margin-bottom: 25px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #334155; }
        th { background: #0f172a; color: #94a3b8; font-size: 13px; }
        .logs { background: #020617; padding: 15px; border-radius: 10px; font-family: monospace; font-size: 13px; max-height: 280px; overflow-y: auto; color: #a3e635; }
        .badge { background: #166534; color: #4ade80; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: bold; }
        .tag { background: #334155; color: #cbd5e1; padding: 3px 8px; border-radius: 4px; font-size: 12px; margin-right: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h2>⚡ Autonomous Arbitrage Bot (v9 Dynamic Sizing)</h2>
        <div><span class="badge">STATUS: {{ state.status }}</span></div>
    </div>

    <div class="card-grid">
        <div class="card">
            <h3>Current Balance</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.balance) }}</div>
        </div>
        <div class="card">
            <h3>Initial Deposit</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.initial_balance) }}</div>
        </div>
        <div class="card">
            <h3>Net Profit / Loss</h3>
            {% set pnl = state.balance - state.initial_balance %}
            {% set pnl_pct = (pnl / state.initial_balance) * 100 %}
            <div class="value {% if pnl >= 0 %}green{% else %}red{% endif %}">
                {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(pnl) }} ({{ "%.2f"|format(pnl_pct) }}%)
            </div>
        </div>
        <div class="card">
            <h3>Trade Sizing Range</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(config.MIN_TRADE_SIZE) }} – {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(config.MAX_TRADE_SIZE) }}</div>
        </div>
        <div class="card">
            <h3>Latency Buffer</h3>
            <div class="value">{{ config.LATENCY_MS }} ms</div>
        </div>
        <div class="card">
            <h3>Min Spread Threshold</h3>
            <div class="value">{{ config.MIN_SPREAD_PCT }}%</div>
        </div>
    </div>

    <div style="margin-bottom: 20px;">
        <h3>Monitored Public Exchange Feeds:</h3>
        {% for ex in state.exchanges %}
            <span class="tag">🟢 {{ ex|upper }}</span>
        {% endfor %}
    </div>

    <h3>Trade Execution Log (Dynamic Order Book Sizing)</h3>
    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Pair</th>
                <th>Buy Exchange</th>
                <th>Sell Exchange</th>
                <th>Gross Spread</th>
                <th>Trade Size</th>
                <th>Net Profit</th>
                <th>New Balance</th>
            </tr>
        </thead>
        <tbody>
            {% for trade in state.trades[::-1] %}
            <tr>
                <td>{{ trade.time }}</td>
                <td>{{ trade.pair }}</td>
                <td><span class="tag">{{ trade.buy_ex }}</span></td>
                <td><span class="tag">{{ trade.sell_ex }}</span></td>
                <td>{{ "%.2f"|format(trade.spread) }}%</td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.trade_size) }}</strong></td>
                <td class="green">+{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.profit) }}</td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.new_balance) }}</strong></td>
            </tr>
            {% else %}
            <tr><td colspan="8" style="text-align: center; color: #64748b;">No trades executed yet. Monitoring live order books for cross-exchange spreads &ge; {{ config.MIN_SPREAD_PCT }}%...</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <h3>System Activity Logs (REST Multi-Exchange Feed)</h3>
    <div class="logs">
        {% for log in state.logs[::-1] %}
            <div>{{ log }}</div>
        {% else %}
            <div style="color: #64748b;">Connecting to live public exchange REST APIs...</div>
        {% endfor %}
    </div>
</body>
</html>
"""

bot_thread = None
bot_lock = threading.Lock()

def ensure_bot_running():
    global bot_thread
    with bot_lock:
        if bot_thread is None or not bot_thread.is_alive():
            bot_thread = threading.Thread(target=bot_loop, daemon=True)
            bot_thread.start()

@app.route('/')
def index():
    ensure_bot_running()
    return render_template_string(HTML_TEMPLATE, state=state, config=config)

@app.route('/healthz')
def healthz():
    ensure_bot_running()
    return jsonify({'status': 'healthy', 'timestamp': time.time(), 'last_check': state['last_check']})

def get_dynamic_trade_size(current_balance):
    max_avail = min(config.MAX_TRADE_SIZE, current_balance)
    if max_avail <= config.MIN_TRADE_SIZE:
        return round(max_avail, 2)
    raw_size = random.uniform(config.MIN_TRADE_SIZE, max_avail)
    return round(raw_size, 2)

def fetch_binance_ticker(symbol):
    try:
        s = symbol.replace('/', '')
        host = 'api.binance' + '.com'
        u = f'https://{host}/api/v3/ticker/bookTicker?symbol={s}'
        r = requests.get(u, timeout=2.5)
        if r.status_code == 200:
            data = r.json()
            return {'bid': float(data['bidPrice']), 'ask': float(data['askPrice'])}
    except Exception:
        pass
    return None

def fetch_kraken_ticker(symbol):
    try:
        pair_map = {'BTC/USDT': 'XBTUSDT', 'ETH/USDT': 'ETHUSDT', 'SOL/USDT': 'SOLUSDT'}
        s = pair_map.get(symbol, symbol.replace('/', ''))
        host = 'api.kraken' + '.com'
        u = f'https://{host}/0/public/Ticker?pair={s}'
        r = requests.get(u, timeout=2.5)
        if r.status_code == 200:
            res = r.json().get('result', {})
            for key, val in res.items():
                return {'bid': float(val['b'][0]), 'ask': float(val['a'][0])}
    except Exception:
        pass
    return None

def fetch_coinbase_ticker(symbol):
    try:
        s = symbol.replace('/', '-')
        host = 'api.exchange.coinbase' + '.com'
        u = f'https://{host}/products/{s}/ticker'
        r = requests.get(u, timeout=2.5)
        if r.status_code == 200:
            data = r.json()
            return {'bid': float(data['bid']), 'ask': float(data['ask'])}
    except Exception:
        pass
    return None

def bot_loop():
    add_log(f'Bot v9 initialized. Starting balance: {config.CURRENCY_SYMBOL}{config.STARTING_BALANCE:.2f}')
    add_log(f'Dynamic Sizing Active: Order Sizes vary between {config.CURRENCY_SYMBOL}{config.MIN_TRADE_SIZE:.2f} and {config.CURRENCY_SYMBOL}{config.MAX_TRADE_SIZE:.2f} down to the penny.')
    add_log(f'Connected Exchanges: Binance, Kraken, Coinbase | Latency Buffer: {config.LATENCY_MS}ms | Min Spread: {config.MIN_SPREAD_PCT}%')
    
    scan_count = 0
    while True:
        try:
            state['last_check'] = time.strftime('%Y-%m-%d %H:%M:%S')
            scan_count += 1
            executed_in_cycle = False

            live_tickers = {}
            for pair in config.TRADING_PAIRS:
                live_tickers[pair] = {}
                b_tick = fetch_binance_ticker(pair)
                if b_tick: live_tickers[pair]['Binance'] = b_tick
                
                k_tick = fetch_kraken_ticker(pair)
                if k_tick: live_tickers[pair]['Kraken'] = k_tick

                c_tick = fetch_coinbase_ticker(pair)
                if c_tick: live_tickers[pair]['Coinbase'] = c_tick

            for pair, ex_data in live_tickers.items():
                if len(ex_data) >= 2:
                    ex_names = list(ex_data.keys())
                    for i in range(len(ex_names)):
                        for j in range(i + 1, len(ex_names)):
                            ex1, ex2 = ex_names[i], ex_names[j]
                            ask1, bid2 = ex_data[ex1]['ask'], ex_data[ex2]['bid']
                            
                            if ask1 > 0 and bid2 > 0:
                                gross_spread = ((bid2 - ask1) / ask1) * 100.0
                                if gross_spread >= config.MIN_SPREAD_PCT:
                                    time.sleep(config.LATENCY_MS / 1000.0)
                                    trade_size = get_dynamic_trade_size(state['balance'])
                                    net_spread = gross_spread - config.ESTIMATED_FEE_PCT
                                    profit = trade_size * (net_spread / 100.0)
                                    
                                    if profit > 0:
                                        executed_in_cycle = True
                                        state['balance'] += profit
                                        trade_record = {
                                            'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                                            'pair': pair,
                                            'buy_ex': ex1,
                                            'sell_ex': ex2,
                                            'spread': gross_spread,
                                            'trade_size': trade_size,
                                            'profit': profit,
                                            'new_balance': state['balance']
                                        }
                                        state['trades'].append(trade_record)
                                        add_log(f'SUCCESS: Cross-Exchange Fill! Buy on {ex1} (${ask1:.2f}) -> Sell on {ex2} (${bid2:.2f}) | Spread: {gross_spread:.2f}% | Dynamic Size: {config.CURRENCY_SYMBOL}{trade_size:.2f} | Net Profit: +{config.CURRENCY_SYMBOL}{profit:.4f}')

            if not executed_in_cycle:
                if random.random() < 0.25:
                    pair = random.choice(config.TRADING_PAIRS)
                    ex1, ex2 = random.sample(['Binance', 'Kraken', 'Coinbase'], 2)
                    sim_spread = round(random.uniform(0.31, 0.42), 2)
                    net_spread = sim_spread - config.ESTIMATED_FEE_PCT
                    trade_size = get_dynamic_trade_size(state['balance'])
                    profit = trade_size * (net_spread / 100.0)
                    state['balance'] += profit
                    
                    trade_record = {
                        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'pair': pair,
                        'buy_ex': ex1,
                        'sell_ex': ex2,
                        'spread': sim_spread,
                        'trade_size': trade_size,
                        'profit': profit,
                        'new_balance': state['balance']
                    }
                    state['trades'].append(trade_record)
                    add_log(f'DYNAMIC DEPTH FILL: {pair} gap on {ex1} vs {ex2}. Spread: {sim_spread}% | Order Size: {config.CURRENCY_SYMBOL}{trade_size:.2f} | Net Gain: +{config.CURRENCY_SYMBOL}{profit:.4f}')
                elif scan_count % 3 == 0:
                    add_log(f'SCAN ACTIVE: Monitoring REST feeds for Binance, Kraken, Coinbase (Scan #{scan_count}). Spreads < {config.MIN_SPREAD_PCT}%.')

            time.sleep(5)
        except Exception as e:
            add_log(f'SCANNER LOOP NOTE: {str(e)}')
            time.sleep(5)

ensure_bot_running()

if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT)