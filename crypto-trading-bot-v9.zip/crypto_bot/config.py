import os

# Trading & Risk Configuration
STARTING_BALANCE = 50.0   # £50 initial paper balance
MIN_TRADE_SIZE = 10.0     # £10 minimum dynamic trade size
MAX_TRADE_SIZE = 50.0     # £50 maximum trade size cap
CURRENCY_SYMBOL = "£"

# Spread & Fee Parameters
MIN_SPREAD_PCT = 0.30     # Minimum net spread required (0.30%)
ESTIMATED_FEE_PCT = 0.20  # Round-trip taker exchange fees (0.10% buy + 0.10% sell)
LATENCY_MS = 200          # 200ms network execution latency buffer

# Exchanges & Pairs for Multi-API Cross-Exchange Monitoring
EXCHANGES = ["binance", "kraken", "coinbase"]
TRADING_PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]

# Web Server Config
PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
