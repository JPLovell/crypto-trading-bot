# Autonomous Crypto Arbitrage Bot (v9 Dynamic Order Sizing)

## Features
- **Dynamic Order Sizing (£10.00 – £50.00)**: Simulates realistic order book depth variance down to the penny (e.g., £13.50, £27.42, £41.80).
- **Lightweight Multi-Exchange REST Monitoring**: Polls live public tickers from Binance, Kraken, and Coinbase.
- **200ms Execution Latency Buffer**: Models internet transmission delays to prevent false fills.
- **0.20% Round-Trip Fee Deduction**: Automatically deducts taker fees from gross spreads before recording profits.
- **Live Flask + Gunicorn Web Dashboard**.

## Deployment on Render
1. Upload `crypto-trading-bot-v9.zip` to GitHub.
2. Build Command: `unzip -o crypto-trading-bot-v9.zip && cp -r crypto_bot/* . && pip install -r requirements.txt`
3. Start Command: `gunicorn --workers 1 --threads 4 --bind 0.0.0.0:$PORT main:app`
