# Autonomous Crypto Trading Bot v8
Lightweight Multi-Exchange Paper Trading Bot.
