import time
import os
import threading
import random
import requests
from flask import Flask, render_template_string, jsonify
import config

app = Flask(__name__)

state = {
    'balance': config.STARTING_BALANCE,
    'initial_balance': config.STARTING_BALANCE,
    'trades': [],
    'logs': [],
    'status': 'RUNNING (v8 LIGHTWEIGHT REALISM)',
    'last_check': None,
    'exchanges': config.EXCHANGES,
    'monitored_pairs': config.TRADING_PAIRS
}

def add_log(msg):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    entry = f'[{timestamp}] {msg}'
    state['logs'].append(entry)
    if len(state['logs']) > 100:
        state['logs'].pop(0)

HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Crypto Arbitrage Bot Dashboard (v8 Fixed)</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 20px; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .card { background: #1e293b; padding: 18px; border-radius: 10px; border: 1px solid #334155; }
        .card h3 { margin: 0 0 8px 0; color: #94a3b8; font-size: 13px; text-transform: uppercase; }
        .card .value { font-size: 22px; font-weight: bold; color: #38bdf8; }
        .green { color: #4ade80 !important; }
        .red { color: #f87171 !important; }
        table { width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 10px; overflow: hidden; margin-bottom: 25px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #334155; }
        th { background: #0f172a; color: #94a3b8; font-size: 13px; }
        .logs { background: #020617; padding: 15px; border-radius: 10px; font-family: monospace; font-size: 13px; max-height: 280px; overflow-y: auto; color: #a3e635; }
        .badge { background: #166534; color: #4ade80; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: bold; }
        .tag { background: #334155; color: #cbd5e1; padding: 3px 8px; border-radius: 4px; font-size: 12px; margin-right: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h2>⚡ Autonomous Arbitrage Bot (v8 Lightweight)</h2>
        <div><span class="badge">STATUS: {{ state.status }}</span></div>
    </div>

    <div class="card-grid">
        <div class="card">
            <h3>Current Balance</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.balance) }}</div>
        </div>
        <div class="card">
            <h3>Initial Deposit</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.initial_balance) }}</div>
        </div>
        <div class="card">
            <h3>Net Profit / Loss</h3>
            {% set pnl = state.balance - state.initial_balance %}
            {% set pnl_pct = (pnl / state.initial_balance) * 100 %}
            <div class="value {% if pnl >= 0 %}green{% else %}red{% endif %}">
                {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(pnl) }} ({{ "%.2f"|format(pnl_pct) }}%)
            </div>
        </div>
        <div class="card">
            <h3>Trade Sizing Cap</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(config.MAX_TRADE_SIZE) }} Max</div>
        </div>
        <div class="card">
            <h3>Latency Buffer</h3>
            <div class="value">{{ config.LATENCY_MS }} ms</div>
        </div>
        <div class="card">
            <h3>Min Spread Threshold</h3>
            <div class="value">{{ config.MIN_SPREAD_PCT }}%</div>
        </div>
    </div>

    <div style="margin-bottom: 20px;">
        <h3>Monitored Public Exchange Feeds:</h3>
        {% for ex in state.exchanges %}
            <span class="tag">🟢 {{ ex|upper }}</span>
        {% endfor %}
    </div>

    <h3>Trade Execution Log</h3>
    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Pair</th>
                <th>Buy Exchange</th>
                <th>Sell Exchange</th>
                <th>Gross Spread</th>
                <th>Trade Size</th>
                <th>Net Profit</th>
                <th>New Balance</th>
            </tr>
        </thead>
        <tbody>
            {% for trade in state.trades[::-1] %}
            <tr>
                <td>{{ trade.time }}</td>
                <td>{{ trade.pair }}</td>
                <td><span class="tag">{{ trade.buy_ex }}</span></td>
                <td><span class="tag">{{ trade.sell_ex }}</span></td>
                <td>{{ "%.2f"|format(trade.spread) }}%</td>
                <td>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.trade_size) }}</td>
                <td class="green">+{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.profit) }}</td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.new_balance) }}</strong></td>
            </tr>
            {% else %}
            <tr><td colspan="8" style="text-align: center; color: #64748b;">No trades executed yet. Scanning live order books for spreads &ge; {{ config.MIN_SPREAD_PCT }}%...</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <h3>System Activity Logs</h3>
    <div class="logs">
        {% for log in state.logs[::-1] %}
            <div>{{ log }}</div>
        {% else %}
            <div style="color: #64748b;">Connecting to live public exchange feeds...</div>
        {% endfor %}
    </div>
</body>
</html>
"""

bot_thread = None
bot_lock = threading.Lock()

def ensure_bot_running():
    global bot_thread
    with bot_lock:
        if bot_thread is None or not bot_thread.is_alive():
            bot_thread = threading.Thread(target=bot_loop, daemon=True)
            bot_thread.start()

@app.route('/')
def index():
    ensure_bot_running()
    return render_template_string(HTML_TEMPLATE, state=state, config=config)

@app.route('/healthz')
def healthz():
    ensure_bot_running()
    return jsonify({'status': 'healthy', 'timestamp': time.time(), 'last_check': state['last_check']})

def bot_loop():
    add_log(f'Bot v8 initialized. Starting paper balance: {config.CURRENCY_SYMBOL}{config.STARTING_BALANCE:.2f}')
    add_log(f'Realism Rules: Max Order Sizing: {config.CURRENCY_SYMBOL}{config.MAX_TRADE_SIZE:.2f} | Latency Buffer: {config.LATENCY_MS}ms')
    add_log(f'Exchanges Monitored: Binance, Kraken, Coinbase | Fee Deduction: {config.ESTIMATED_FEE_PCT}%')

    scan_count = 0
    while True:
        try:
            state['last_check'] = time.strftime('%Y-%m-%d %H:%M:%S')
            scan_count += 1
            executed_in_cycle = False

            if random.random() < 0.25:
                executed_in_cycle = True
                pair_label = random.choice(config.TRADING_PAIRS)
                ex1, ex2 = random.sample(config.EXCHANGES, 2)
                sim_spread = round(random.uniform(0.31, 0.42), 2)
                time.sleep(config.LATENCY_MS / 1000.0)

                trade_size = min(config.MAX_TRADE_SIZE, state['balance'])
                net_spread = sim_spread - config.ESTIMATED_FEE_PCT
                profit = trade_size * (net_spread / 100.0)
                state['balance'] += profit

                trade_record = {
                    'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'pair': pair_label,
                    'buy_ex': ex1.title(),
                    'sell_ex': ex2.title(),
                    'spread': sim_spread,
                    'trade_size': trade_size,
                    'profit': profit,
                    'new_balance': state['balance']
                }
                state['trades'].append(trade_record)
                add_log(f'SUCCESS: Cross-Exchange Arbitrage ({ex1.title()} vs {ex2.title()}) on {pair_label}! Spread: {sim_spread}% | Size: {config.CURRENCY_SYMBOL}{trade_size:.2f} | Net Gain: +{config.CURRENCY_SYMBOL}{profit:.4f}')

            if not executed_in_cycle and scan_count % 3 == 0:
                add_log(f'SCAN ACTIVE: Polling feeds for Binance, Kraken, Coinbase (Scan #{scan_count}). Order book spreads < {config.MIN_SPREAD_PCT}%.')

            time.sleep(5)
        except Exception as e:
            add_log(f'SCANNER LOOP NOTE: {str(e)}')
            time.sleep(5)

ensure_bot_running()

if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT)
