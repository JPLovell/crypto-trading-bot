import time, os, threading, random, json, requests
from flask import Flask, render_template_string, jsonify
import config, kraken_api

app = Flask(__name__)

state = {
    'balance': config.STARTING_BALANCE,
    'initial_balance': config.STARTING_BALANCE,
    'trades': [],
    'logs': [],
    'status': 'RUNNING (v24 ZERO-SLIPPAGE POST-ONLY LIMIT ENGINE)',
    'last_check': None,
    'monitored_pairs': config.MONITORED_PAIRS,
    'scans_completed': 0,
    'api_authenticated': False,
    'signals_detected': 0,
    'fills_captured': 0,
    'hft_missed': 0,
    'depth_rejected': 0,
    'auto_convert_active': True,
    'open_positions': {}
}

bot_lock = threading.Lock()
last_trade_time = 0

def add_log(msg):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    entry = f'[{timestamp}] {msg}'
    state['logs'].append(entry)
    if len(state['logs']) > 150:
        state['logs'].pop(0)

HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Crypto Trading Bot (v24 Zero-Slippage Post-Only Limit Engine)</title>
    <meta http-equiv="refresh" content="8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0b0f19; color: #f8fafc; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #1e293b; padding-bottom: 15px; margin-bottom: 20px; flex-wrap: wrap; gap: 10px; }
        .header h2 { margin: 0; color: #f8fafc; font-size: 20px; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 20px; }
        .card { background: #131d31; padding: 16px; border-radius: 10px; border: 1px solid #1e293b; }
        .card h3 { margin: 0 0 6px 0; color: #94a3b8; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
        .card .value { font-size: 20px; font-weight: bold; color: #38bdf8; }
        .green { color: #4ade80 !important; }
        .red { color: #f87171 !important; }
        .yellow { color: #facc15 !important; }
        .stat-banner { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; background: #0f172a; padding: 14px; border-radius: 8px; border: 1px solid #1e293b; margin-bottom: 22px; font-size: 13px; }
        .stat-item { display: flex; flex-direction: column; }
        .stat-item span:first-child { color: #94a3b8; font-size: 11px; text-transform: uppercase; }
        .stat-item span:last-child { font-size: 16px; font-weight: bold; color: #f8fafc; margin-top: 2px; }
        table { width: 100%; border-collapse: collapse; background: #131d31; border-radius: 10px; overflow: hidden; margin-bottom: 25px; font-size: 13px; }
        th, td { padding: 11px 12px; text-align: left; border-bottom: 1px solid #1e293b; }
        th { background: #0b0f19; color: #94a3b8; font-size: 12px; }
        .logs { background: #050811; padding: 15px; border-radius: 10px; font-family: 'Courier New', Courier, monospace; font-size: 12px; max-height: 300px; overflow-y: auto; color: #a3e635; border: 1px solid #1e293b; }
        .badge { background: #065f46; color: #34d399; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; display: inline-block; }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h2>⚡ Autonomous Trading Bot (v24 Zero-Slippage Post-Only Limit Engine)</h2>
            <div style="font-size: 12px; color: #94a3b8; margin-top: 4px;">Post-Only Limit Orders (oflags=post) | £10.00 Fixed Cap | Depth Filter (£50+ Buffer)</div>
        </div>
        <div>
            <span class="badge">STATUS: {{ state.status }}</span>
        </div>
    </div>

    <div class="card-grid">
        <div class="card">
            <h3>GBP Liquid Cash Balance</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.balance) }}</div>
        </div>
        <div class="card">
            <h3>Execution Protocol</h3>
            <div class="value green">LIMIT (POST-ONLY)</div>
        </div>
        <div class="card">
            <h3>Order Book Depth Filter</h3>
            <div class="value green">ACTIVE (£50+ Buffer)</div>
        </div>
        <div class="card">
            <h3>Kraken API Auth</h3>
            <div class="value">
                {% if state.api_authenticated %}
                    <span class="green">🟢 AUTHENTICATED</span>
                {% else %}
                    <span class="yellow">🟡 CONNECTING...</span>
                {% endif %}
            </div>
        </div>
    </div>

    <div class="stat-banner">
        <div class="stat-item">
            <span>Signals Detected</span>
            <span style="color: #38bdf8;">{{ state.signals_detected }}</span>
        </div>
        <div class="stat-item">
            <span>Completed Fills</span>
            <span class="green">{{ state.fills_captured }}</span>
        </div>
        <div class="stat-item">
            <span>Depth Rejections</span>
            <span style="color: #facc15;">{{ state.depth_rejected }}</span>
        </div>
        <div class="stat-item">
            <span>Live Execution Mode</span>
            <span>
                {% if config.LIVE_TRADING_ENABLED and config.KRAKEN_API_KEY %}
                    <span style="color: #ef4444; font-weight: bold;">🔴 POST-ONLY LIMIT API ORDERS</span>
                {% else %}
                    <span style="color: #facc15;">🟡 SIMULATION MODE</span>
                {% endif %}
            </span>
        </div>
    </div>

    <h3 style="margin-bottom: 10px; font-size: 15px;">Kraken Execution & Zero-Slippage Log</h3>
    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Market Pair</th>
                <th>Action / Strategy</th>
                <th>TXID / Status</th>
                <th>Trade Size</th>
                <th>Net Profit</th>
                <th>GBP Balance</th>
            </tr>
        </thead>
        <tbody>
            {% for trade in state.trades[::-1] %}
            <tr>
                <td>{{ trade.time }}</td>
                <td><strong>{{ trade.pair }}</strong></td>
                <td><span style="background: #1e293b; color: #38bdf8; padding: 2px 6px; border-radius: 4px; font-size: 11px;">{{ trade.strategy }}</span></td>
                <td style="font-family: monospace; font-size: 11px; color: #a3e635;">{{ trade.txid }}</td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.trade_size) }}</strong></td>
                <td class="green"><strong>+{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.profit) }}</strong></td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.new_balance) }}</strong></td>
            </tr>
            {% else %}
            <tr><td colspan="7" style="text-align: center; color: #64748b; padding: 20px;">Bot is scanning Kraken order books with post-only limit orders and £50+ liquidity filters...</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <h3 style="margin-bottom: 10px; font-size: 15px;">Live Engine Logs (Limit Orders & Depth Monitor)</h3>
    <div class="logs">
        {% for log in state.logs[::-1] %}
            <div>{{ log }}</div>
        {% endfor %}
    </div>
</body>
</html>
"""

bot_thread = None

def auto_convert_crypto_loop():
    """Periodically check Kraken wallet balances and convert crypto holdings back into GBP cash ONLY when profit target is met."""
    asset_pair_map = {
        'XXRP': 'XRP/GBP', 'XRP': 'XRP/GBP',
        'ATOM': 'ATOM/GBP', 'XXBT': 'BTC/GBP', 'XBT': 'BTC/GBP',
        'XETH': 'ETH/GBP', 'ETH': 'ETH/GBP', 'SOL': 'SOL/GBP',
        'LTC': 'LTC/GBP', 'XLTC': 'LTC/GBP', 'ADA': 'ADA/GBP',
        'DOT': 'DOT/GBP', 'LINK': 'LINK/GBP', 'AVAX': 'AVAX/GBP'
    }

    while True:
        try:
            if config.LIVE_TRADING_ENABLED and config.KRAKEN_API_KEY and config.KRAKEN_API_SECRET:
                balances, err = kraken_api.query_balances(config.KRAKEN_API_KEY, config.KRAKEN_API_SECRET)
                if balances:
                    state['api_authenticated'] = True
                    gbp_cash = float(balances.get('ZGBP', balances.get('GBP', 0.0)))
                    state['balance'] = gbp_cash

                    for asset, vol_str in balances.items():
                        if asset in ['ZGBP', 'GBP']:
                            continue
                        try:
                            vol = float(vol_str)
                            if vol > 0.0001 and asset in asset_pair_map:
                                pair_display = asset_pair_map[asset]
                                api_pair = config.SYMBOL_MAP.get(pair_display, pair_display.replace('/', ''))
                                
                                ticker, t_err = kraken_api.get_ticker(api_pair)
                                if ticker:
                                    current_bid = ticker['bid']
                                    pos_info = state['open_positions'].get(asset, {})
                                    buy_price = pos_info.get('buy_price', None)
                                    
                                    if buy_price:
                                        target_price = buy_price * 1.0120
                                        if current_bid >= target_price:
                                            add_log(f"PROFIT TARGET REACHED! {asset} Bid: £{current_bid:.4f} >= Target: £{target_price:.4f}. Placing Post-Only Limit Sell...")
                                            txid, err = kraken_api.place_live_order(
                                                symbol=api_pair, side='sell', volume=round(vol, 4),
                                                api_key=config.KRAKEN_API_KEY, api_secret=config.KRAKEN_API_SECRET,
                                                ordertype='limit', price=round(current_bid, 4), oflags='post'
                                            )
                                            if txid:
                                                profit_est = (current_bid - buy_price) * vol
                                                add_log(f"AUTO-GBP POST-ONLY LIMIT SELL EXECUTED! Sold {vol:.4f} {asset} -> GBP | Profit: +£{profit_est:.2f} | TXID: {txid}")
                                                state['trades'].append({
                                                    'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                                                    'pair': pair_display,
                                                    'strategy': 'Post-Only Limit Auto-Sell',
                                                    'txid': txid,
                                                    'trade_size': vol * current_bid,
                                                    'profit': max(0.01, profit_est),
                                                    'new_balance': gbp_cash
                                                })
                                                state['open_positions'].pop(asset, None)
                                            elif err:
                                                add_log(f"LIMIT SELL NOTICE ({asset}): {err}")
                                        else:
                                            pct_diff = ((current_bid - buy_price) / buy_price) * 100
                                            add_log(f"PROFIT GATE ACTIVE: Holding {vol:.4f} {asset} ({pct_diff:+.2f}%). Bid: £{current_bid:.4f} < Target: £{target_price:.4f}. Waiting for profit target.")
                                    else:
                                        if vol * current_bid >= 5.0:
                                            add_log(f"LIQUIDATING PREEXISTING POSITION: Selling {vol:.4f} {asset} via Limit Order...")
                                            txid, err = kraken_api.place_live_order(
                                                symbol=api_pair, side='sell', volume=round(vol, 4),
                                                api_key=config.KRAKEN_API_KEY, api_secret=config.KRAKEN_API_SECRET,
                                                ordertype='limit', price=round(current_bid, 4), oflags='post'
                                            )
                                            if txid:
                                                add_log(f"PREEXISTING {asset} POSITION LIQUIDATED TO GBP! TXID: {txid}")
                        except Exception as ex:
                            pass
        except Exception as e:
            pass
        time.sleep(15)

def bot_loop():
    global last_trade_time
    add_log(f"Bot v24 initialized with Zero-Slippage Post-Only Limit Engine.")
    add_log(f"Order Book Depth Buffer (£50+ required) & Post-Only Execution Active.")
    
    conv_thread = threading.Thread(target=auto_convert_crypto_loop, daemon=True)
    conv_thread.start()

    while True:
        try:
            state['last_check'] = time.strftime('%Y-%m-%d %H:%M:%S')
            now_time = time.time()
            
            if config.LIVE_TRADING_ENABLED and config.KRAKEN_API_KEY and config.KRAKEN_API_SECRET:
                balances, err = kraken_api.query_balances(config.KRAKEN_API_KEY, config.KRAKEN_API_SECRET)
                if balances:
                    state['api_authenticated'] = True
                    gbp_cash = float(balances.get('ZGBP', balances.get('GBP', 0.0)))
                    state['balance'] = gbp_cash

            time_since_last = now_time - last_trade_time
            if time_since_last >= config.COOLDOWN_SEC and len(state['open_positions']) == 0:
                selected_pair = random.choice(["XRP/GBP", "BTC/GBP", "ETH/GBP", "SOL/GBP", "ATOM/GBP", "LTC/GBP"])
                api_pair = config.SYMBOL_MAP.get(selected_pair, selected_pair.replace('/', ''))
                
                book, b_err = kraken_api.get_order_book(api_pair, count=10)
                if book:
                    ask_depth = book['ask_depth_gbp']
                    bid_price = book['top_bid']
                    state['signals_detected'] += 1
                    
                    if ask_depth < config.MIN_ORDERBOOK_DEPTH_GBP:
                        add_log(f"DEPTH REJECTED ({selected_pair}): Ask depth £{ask_depth:.2f} < £50.00 threshold. Preventing price impact.")
                        state['depth_rejected'] += 1
                    else:
                        if config.LIVE_TRADING_ENABLED and config.KRAKEN_API_KEY and config.KRAKEN_API_SECRET:
                            if state['balance'] >= config.MIN_TRADE_SIZE:
                                trade_size = config.MAX_TRADE_SIZE
                                target_buy_price = bid_price  # Place buy limit order at top bid to sit on book as Maker
                                vol = round(trade_size / target_buy_price, 4)
                                
                                if vol > 0.0001:
                                    add_log(f"SMART SIGNAL DETECTED: Placing POST-ONLY LIMIT BUY for {selected_pair} at Bid £{target_buy_price:.4f} (£{trade_size:.2f})...")
                                    txid, err = kraken_api.place_live_order(
                                        symbol=api_pair, side='buy', volume=vol,
                                        api_key=config.KRAKEN_API_KEY, api_secret=config.KRAKEN_API_SECRET,
                                        ordertype='limit', price=round(target_buy_price, 4), oflags='post'
                                    )
                                    if txid:
                                        last_trade_time = now_time
                                        state['fills_captured'] += 1
                                        asset_name = api_pair.replace('XBT', 'BTC').replace('GBP', '')
                                        state['open_positions'][asset_name] = {
                                            'buy_price': target_buy_price,
                                            'volume': vol,
                                            'timestamp': now_time
                                        }
                                        add_log(f"KRAKEN POST-ONLY LIMIT BUY EXECUTED! TXID: {txid} | Pair: {selected_pair} | Vol: {vol} @ £{target_buy_price:.4f}")
                                        state['trades'].append({
                                            'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                                            'pair': selected_pair,
                                            'strategy': 'Post-Only Limit Buy (£10 Cap)',
                                            'txid': txid,
                                            'trade_size': trade_size,
                                            'profit': 0.00,
                                            'new_balance': state['balance']
                                        })
                                    elif err:
                                        add_log(f"POST-ONLY BUY NOTICE ({selected_pair}): {err}")
                                        state['hft_missed'] += 1
                            else:
                                add_log(f"HOLDING POSITION: GBP cash (£{state['balance']:.2f}) < £10.00. Waiting for open position to hit +1.20% profit target.")
            
            time.sleep(12)
        except Exception as e:
            add_log(f"ENGINE NOTICE: {str(e)}")
            time.sleep(12)

def ensure_bot_running():
    global bot_thread
    with bot_lock:
        if bot_thread is None or not bot_thread.is_alive():
            bot_thread = threading.Thread(target=bot_loop, daemon=True)
            bot_thread.start()

@app.route('/')
def index():
    ensure_bot_running()
    return render_template_string(HTML_TEMPLATE, state=state, config=config)

@app.route('/healthz')
def healthz():
    ensure_bot_running()
    return jsonify({'status': 'healthy', 'balance': state['balance']})

if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT)
