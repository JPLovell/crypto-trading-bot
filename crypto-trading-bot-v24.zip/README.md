# Crypto Trading Bot (v24 Zero-Slippage Post-Only Limit Engine)

### Key Features:
- **Kraken Post-Only Limit Execution (`oflags=post`)**: Uses `ordertype='limit'` and `oflags='post'` to guarantee Maker status and zero slippage.
- **Top Bid Limit Entry**: Places limit buy orders at the top bid price (`bid_price`) so orders enter the order book directly as Maker liquidity.
- **Order Book Depth Filter (£50+ Buffer)**: Verifies order book depth before trading to eliminate price impact.
- **Fixed £10.00 Position Cap**: Preserves ~75% of portfolio in liquid cash.
- **+1.20% Net Profit Target Gate**: Holds positions until price reaches target margin above entry price.
