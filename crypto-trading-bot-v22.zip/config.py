import os

# Account & Capital Settings
STARTING_BALANCE = 50.0          # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size threshold
MAX_TRADE_SIZE = 10.0            # £10 fixed trade size cap (preserves cash buffer)
MAX_WORKING_CAPITAL = 50.0       # Risk Ring-Fence Cap (£50 max active capital)
CURRENCY_SYMBOL = "£"

# Kraken Pro Fee & Execution Parameters
PRIMARY_EXCHANGE = "Kraken Pro"
TAKER_FEE_PCT = 0.40             # Kraken Pro standard entry taker fee per trade (0.40%)
ROUNDTRIP_FEE_PCT = 0.80         # Round-trip buy taker + sell taker fee (0.80%)
MIN_PROFIT_GATE_PCT = 1.20       # Minimum price gain required before auto-sell (+1.20% net profit gate)
COOLDOWN_SEC = 90                # Minimum 90s cooldown between buy orders to prevent over-trading

# Live Environment Variables & API Credentials
KRAKEN_API_KEY = os.environ.get("KRAKEN_API_KEY", "").strip()
KRAKEN_API_SECRET = os.environ.get("KRAKEN_API_SECRET", "").strip()
LIVE_TRADING_ENABLED = os.environ.get("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1", "yes"]

# Monitored Kraken Direct GBP Markets
MONITORED_PAIRS = [
    "BTC/GBP", "ETH/GBP", "SOL/GBP", "XRP/GBP", "ADA/GBP", 
    "DOT/GBP", "LINK/GBP", "AVAX/GBP", "NEAR/GBP", "DOGE/GBP",
    "LTC/GBP", "ATOM/GBP", "FIL/GBP", "UNI/GBP"
]

# Kraken API Symbol Translation Map
SYMBOL_MAP = {
    "BTC/GBP": "XBTGBP", "ETH/GBP": "ETHGBP", "SOL/GBP": "SOLGBP",
    "XRP/GBP": "XRPGBP", "ADA/GBP": "ADAGBP", "DOT/GBP": "DOTGBP",
    "LINK/GBP": "LINKGBP", "AVAX/GBP": "AVAXGBP", "NEAR/GBP": "NEARGBP",
    "DOGE/GBP": "DOGEGBP", "LTC/GBP": "LTCGBP", "ATOM/GBP": "ATOMGBP",
    "FIL/GBP": "FILGBP", "UNI/GBP": "UNIGBP"
}

PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
