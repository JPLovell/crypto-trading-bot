import time, requests, urllib.parse, hashlib, hmac, base64

API_URL = "https://api." + "kraken.com"

def get_kraken_signature(urlpath, data, secret):
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode('utf-8')
    message = urlpath.encode('utf-8') + hashlib.sha256(encoded).digest()
    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    return base64.b64encode(mac.digest()).decode('utf-8')

def kraken_request(uri_path, data, ak, as_val):
    if not ak or not as_val:
        return {"error": ["Missing API credentials"]}
    headers = {
        'API-Key': ak.strip(),
        'API-Sign': get_kraken_signature(uri_path, data, as_val.strip()),
        'User-Agent': 'Kraken Live Bot v18'
    }
    try:
        res = requests.post(API_URL + uri_path, headers=headers, data=data, timeout=8.0)
        return res.json()
    except Exception as e:
        return {"error": [str(e)]}

def query_balances(ak, as_val):
    if not ak or not as_val:
        return None, "API keys missing"
    data = {'nonce': str(int(time.time() * 1000))}
    res = kraken_request('/0/private/Balance', data, ak, as_val)
    if res.get('error'):
        return None, ", ".join(res['error'])
    return res.get('result', {}), None

def place_live_order(symbol, side, volume, ak, as_val, ordertype="market", price=None, oflags=""):
    data = {
        'nonce': str(int(time.time() * 1000)),
        'pair': symbol,
        'type': side,
        'ordertype': ordertype,
        'volume': str(volume)
    }
    if price:
        data['price'] = str(price)
    if oflags:
        data['oflags'] = oflags
    res = kraken_request('/0/private/AddOrder', data, ak, as_val)
    if res.get('error') and len(res['error']) > 0:
        return None, ", ".join(res['error'])
    result = res.get('result', {})
    txid = result.get('txid', ['UNKNOWN'])[0]
    return txid, None
