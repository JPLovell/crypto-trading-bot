# Crypto Trading Bot v16 (Auto-Convert to GBP Engine)

Supports 24/7 continuous trading and automatic round-trip conversion back to GBP cash.
