# ⚡ Autonomous Crypto Arbitrage Bot (v6)

A lightweight, automated cryptocurrency arbitrage paper trading application designed for 24/7 deployment on Render.

## Features
- **Automatic Continuous Scanning**: Background market monitoring loop checks BTC/USDT, ETH/USDT, and SOL/USDT order books every 5 seconds.
- **Heartbeat & Self-Healing Guard**: Automatically resumes scanning thread on HTTP dashboard updates or UptimeRobot health checks.
- **Real-Time Web Dashboard**: Displays current paper balance, net PnL, active trade execution table, and timestamped system activity logs.
- **Render Ready**: Single-command build and run configuration.
