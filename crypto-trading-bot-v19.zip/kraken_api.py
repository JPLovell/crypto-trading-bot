import time, requests, urllib.parse, hashlib, hmac, base64

API_URL = "https://api." + "kraken.com"

def get_kraken_signature(urlpath, data, secret):
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode('utf-8')
    message = urlpath.encode('utf-8') + hashlib.sha256(encoded).digest()
    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    return base64.b64encode(mac.digest()).decode('utf-8')

def kraken_request(uri_path, data, api_key, api_secret):
    if not api_key or not api_secret:
        return {"error": ["Missing API credentials"]}
    headers = {
        'API-Key': api_key.strip(),
        'API-Sign': get_kraken_signature(uri_path, data, api_secret.strip()),
        'User-Agent': 'Kraken Live Bot v19'
    }
    try:
        res = requests.post(API_URL + uri_path, headers=headers, data=data, timeout=8.0)
        return res.json()
    except Exception as e:
        return {"error": [str(e)]}

def query_balances(api_key, api_secret):
    if not api_key or not api_secret:
        return None, "API keys missing"
    data = {'nonce': str(int(time.time() * 1000))}
    res = kraken_request('/0/private/Balance', data, api_key, api_secret)
    if res.get('error'):
        return None, ", ".join(res['error'])
    return res.get('result', {}), None

def place_live_order(symbol, side, volume, api_key, api_secret, ordertype="market", price=None, oflags=""):
    data = {
        'nonce': str(int(time.time() * 1000)),
        'pair': symbol,
        'type': side,               # 'buy' or 'sell'
        'ordertype': ordertype,     # 'market' or 'limit'
        'volume': str(volume)
    }
    if price:
        data['price'] = str(price)
    if oflags:
        data['oflags'] = oflags
    res = kraken_request('/0/private/AddOrder', data, api_key, api_secret)
    if res.get('error') and len(res['error']) > 0:
        return None, ", ".join(res['error'])
    result = res.get('result', {})
    txid = result.get('txid', ['UNKNOWN'])[0]
    return txid, None
