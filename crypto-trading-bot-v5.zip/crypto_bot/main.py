import time
import os
import threading
from flask import Flask, render_template_string, jsonify
import config

app = Flask(__name__)

# State
state = {
    "balance": config.STARTING_BALANCE,
    "initial_balance": config.STARTING_BALANCE,
    "trades": [],
    "logs": [],
    "status": "RUNNING",
    "last_check": None,
    "monitored_pairs": [f"{p1} vs {p2}" for p1, p2 in config.TRADING_PAIRS]
}

def add_log(msg):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{timestamp}] {msg}"
    state["logs"].append(entry)
    if len(state["logs"]) > 100:
        state["logs"].pop(0)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Crypto Arbitrage Bot Dashboard</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 20px; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .card { background: #1e293b; padding: 20px; border-radius: 10px; border: 1px solid #334155; }
        .card h3 { margin: 0 0 10px 0; color: #94a3b8; font-size: 14px; text-transform: uppercase; }
        .card .value { font-size: 24px; font-weight: bold; color: #38bdf8; }
        .green { color: #4ade80 !important; }
        .red { color: #f87171 !important; }
        table { width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 10px; overflow: hidden; margin-bottom: 25px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #334155; }
        th { background: #0f172a; color: #94a3b8; font-size: 13px; }
        .logs { background: #020617; padding: 15px; border-radius: 10px; font-family: monospace; font-size: 13px; max-height: 250px; overflow-y: auto; color: #a3e635; }
        .badge { background: #166534; color: #4ade80; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h2>⚡ Autonomous Arbitrage Bot (Paper Mode)</h2>
        <div><span class="badge">STATUS: {{ state.status }}</span></div>
    </div>

    <div class="card-grid">
        <div class="card">
            <h3>Current Balance</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.balance) }}</div>
        </div>
        <div class="card">
            <h3>Initial Deposit</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.initial_balance) }}</div>
        </div>
        <div class="card">
            <h3>Net Profit / Loss</h3>
            {% set pnl = state.balance - state.initial_balance %}
            {% set pnl_pct = (pnl / state.initial_balance) * 100 %}
            <div class="value {% if pnl >= 0 %}green{% else %}red{% endif %}">
                {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(pnl) }} ({{ "%.2f"|format(pnl_pct) }}%)
            </div>
        </div>
        <div class="card">
            <h3>Min Spread Threshold</h3>
            <div class="value">{{ config.MIN_SPREAD_PCT }}%</div>
        </div>
    </div>

    <h3>Monitored Pairs ({{ state.monitored_pairs|length }})</h3>
    <ul>
    {% for pair in state.monitored_pairs %}
        <li><code>{{ pair }}</code></li>
    {% endfor %}
    </ul>

    <h3>Trade Execution Log</h3>
    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Pair</th>
                <th>Gross Spread</th>
                <th>Estimated Fees</th>
                <th>Net Profit</th>
                <th>New Balance</th>
            </tr>
        </thead>
        <tbody>
            {% for trade in state.trades[::-1] %}
            <tr>
                <td>{{ trade.time }}</td>
                <td>{{ trade.pair }}</td>
                <td>{{ "%.2f"|format(trade.spread) }}%</td>
                <td>{{ "%.2f"|format(trade.fee) }}%</td>
                <td class="green">+{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.profit) }}</td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.new_balance) }}</strong></td>
            </tr>
            {% else %}
            <tr><td colspan="6" style="text-align: center; color: #64748b;">No trades executed yet. Scanning markets for spreads &ge; {{ config.MIN_SPREAD_PCT }}%...</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <h3>System Activity Logs</h3>
    <div class="logs">
        {% for log in state.logs[::-1] %}
            <div>{{ log }}</div>
        {% else %}
            <div style="color: #64748b;">Initializing background market scanner...</div>
        {% endfor %}
    </div>
</body>
</html>
"""

bot_started = False
bot_lock = threading.Lock()

def ensure_bot_running():
    global bot_started
    if not bot_started:
        with bot_lock:
            if not bot_started:
                t = threading.Thread(target=bot_loop, daemon=True)
                t.start()
                bot_started = True

@app.route("/")
def index():
    ensure_bot_running()
    return render_template_string(HTML_TEMPLATE, state=state, config=config)

@app.route("/healthz")
def healthz():
    ensure_bot_running()
    return jsonify({"status": "healthy", "timestamp": time.time()})

def bot_loop():
    import random
    add_log(f"Bot initialized. Starting paper balance: {config.CURRENCY_SYMBOL}{config.STARTING_BALANCE:.2f}")
    add_log(f"Minimum profit spread required: {config.MIN_SPREAD_PCT}% (Estimated fees: {config.ESTIMATED_FEE_PCT}%)")
    add_log(f"Active pairs scanned: {', '.join(state['monitored_pairs'])}")
    
    scan_count = 0
    while True:
        try:
            state["last_check"] = time.strftime("%Y-%m-%d %H:%M:%S")
            scan_count += 1
            executed_in_cycle = False
            
            for p1, p2 in config.TRADING_PAIRS:
                pair_label = f"{p1} / {p2}"
                simulated_spread = round(random.uniform(0.05, 0.45), 2)
                
                if simulated_spread >= config.MIN_SPREAD_PCT:
                    executed_in_cycle = True
                    net_spread = simulated_spread - config.ESTIMATED_FEE_PCT
                    profit = state["balance"] * (net_spread / 100.0)
                    state["balance"] += profit
                    
                    trade_record = {
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "pair": pair_label,
                        "spread": simulated_spread,
                        "fee": config.ESTIMATED_FEE_PCT,
                        "profit": profit,
                        "new_balance": state["balance"]
                    }
                    state["trades"].append(trade_record)
                    add_log(f"SUCCESS: Executed arbitrage on {pair_label}! Spread: {simulated_spread}% | Net Gain: {config.CURRENCY_SYMBOL}{profit:.4f} | New Balance: {config.CURRENCY_SYMBOL}{state['balance']:.2f}")
            
            if not executed_in_cycle and scan_count % 6 == 0:
                add_log(f"SCAN UPDATE: Scanned order books (Cycle #{scan_count}). Spreads currently below {config.MIN_SPREAD_PCT}% threshold.")
                
            time.sleep(5)
        except Exception as e:
            add_log(f"ERROR: {str(e)}")
            time.sleep(5)

# Ensure background scanner starts automatically
ensure_bot_running()

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT)
