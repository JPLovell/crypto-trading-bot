import os

STARTING_BALANCE = 50.0          # Fallback starting balance (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size
MAX_TRADE_SIZE = 25.0            # £25 max trade size cap
MAX_WORKING_CAPITAL = 50.0       # Risk Ring-Fence Cap
CURRENCY_SYMBOL = "£"

PRIMARY_EXCHANGE = "Kraken Pro"
TAKER_FEE_PCT = 0.40             # Kraken Pro standard taker fee (0.40%)
ROUNDTRIP_FEE_PCT = 0.80         # Roundtrip fee (0.80%)
MIN_SPREAD_THRESHOLD = 0.88      # Minimum spread threshold
MIN_DEPTH_USD = 50.0             # $50 top-of-book depth filter
LATENCY_BUFFER_MS = 25           # Latency buffer

KRAKEN_API_KEY = os.environ.get("KRAKEN_API_KEY", "").strip()
KRAKEN_API_SECRET = os.environ.get("KRAKEN_API_SECRET", "").strip()
LIVE_TRADING_ENABLED = os.environ.get("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1", "yes"]

MONITORED_PAIRS = [
    "BTC/GBP", "ETH/GBP", "SOL/GBP", "XRP/GBP", "ADA/GBP", 
    "DOT/GBP", "LINK/GBP", "AVAX/GBP", "NEAR/GBP", "DOGE/GBP",
    "LTC/GBP", "ATOM/GBP", "FIL/GBP", "UNI/GBP", "USDT/GBP",
    "NEAR/USDT", "SOL/USDT", "FIL/USDT", "UNI/USDT", "INJ/USDT",
    "TIA/USDT", "RENDER/USDT", "SUI/USDT", "PEPE/USDT", "FET/USDT",
    "ARB/USDT", "OP/USDT", "DOT/USDT", "LINK/USDT", "BTC/USDT"
]

PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
