import time
import requests
import hashlib
import hmac
import base64
import urllib.parse

KRAKEN_BASE_URL = "https://api." + "kraken.com"

def get_kraken_signature(urlpath, data, secret):
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode('utf-8')
    message = urlpath.encode('utf-8') + hashlib.sha256(encoded).digest()
    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    sigdigest = base64.b64encode(mac.digest())
    return sigdigest.decode('utf-8')

def kraken_private_request(urlpath, data, api_key, api_secret):
    data['nonce'] = str(int(time.time() * 1000000))
    headers = {
        'API-Key': api_key,
        'API-Sign': get_kraken_signature(urlpath, data, api_secret),
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    resp = requests.post(KRAKEN_BASE_URL + urlpath, headers=headers, data=data, timeout=10)
    return resp.json()

def get_account_balance(api_key, api_secret):
    if not api_key or not api_secret:
        return None, "Missing KRAKEN_API_KEY or KRAKEN_API_SECRET environment variables"
    try:
        res = kraken_private_request('/0/private/Balance', {}, api_key, api_secret)
        if res.get('error') and len(res['error']) > 0:
            return None, f"Kraken API Error: {', '.join(res['error'])}"
        return res.get('result', {}), None
    except Exception as e:
        return None, str(e)

def place_spot_order(api_key, api_secret, pair, side, ordertype, volume, price=None, ioc=True):
    if not api_key or not api_secret:
        return None, "Missing KRAKEN_API_KEY or KRAKEN_API_SECRET environment variables"
    
    clean_pair = pair.replace('/', '')
    if clean_pair.startswith('BTC'):
        clean_pair = clean_pair.replace('BTC', 'XBT')

    data = {
        'pair': clean_pair,
        'type': side,
        'ordertype': ordertype,
        'volume': str(volume)
    }
    if ordertype == 'limit' and price:
        data['price'] = str(price)
        if ioc:
            data['oflags'] = 'ioc'

    try:
        res = kraken_private_request('/0/private/AddOrder', data, api_key, api_secret)
        if res.get('error') and len(res['error']) > 0:
            return None, f"Kraken API Error: {', '.join(res['error'])}"
        return res.get('result', {}), None
    except Exception as e:
        return None, str(e)
