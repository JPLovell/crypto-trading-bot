# Crypto Trading Bot v15 (Direct Kraken Private API Live Trading Engine)

This release implements real HTTP POST requests to Kraken's `/0/private/AddOrder` and `/0/private/Balance` endpoints using HMAC-SHA512 request signing.

## Key Features
1. Live REST API order routing directly to Kraken matching engine.
2. Real-time balance retrieval via `/0/private/Balance`.
3. HMAC-SHA512 private request signing.
