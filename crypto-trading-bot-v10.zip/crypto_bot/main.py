import time
import os
import threading
import random
import requests
from flask import Flask, render_template_string, jsonify
import config

app = Flask(__name__)

state = {
    'balance': config.STARTING_BALANCE,
    'initial_balance': config.STARTING_BALANCE,
    'trades': [],
    'logs': [],
    'status': 'RUNNING (v10 BINANCE 30-PAIR)',
    'last_check': None,
    'exchange': config.PRIMARY_EXCHANGE,
    'monitored_pairs': config.MONITORED_PAIRS,
    'scans_completed': 0
}

def add_log(msg):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    entry = f'[{timestamp}] {msg}'
    state['logs'].append(entry)
    if len(state['logs']) > 120:
        state['logs'].pop(0)

HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Crypto Trading Bot Dashboard (v10 Binance 30-Pair Scanner)</title>
    <meta http-equiv="refresh" content="10">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0b0f19; color: #f8fafc; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #1e293b; padding-bottom: 15px; margin-bottom: 20px; flex-wrap: wrap; gap: 10px; }
        .header h2 { margin: 0; color: #f8fafc; font-size: 20px; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 22px; }
        .card { background: #131d31; padding: 16px; border-radius: 10px; border: 1px solid #1e293b; }
        .card h3 { margin: 0 0 6px 0; color: #94a3b8; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
        .card .value { font-size: 20px; font-weight: bold; color: #38bdf8; }
        .green { color: #4ade80 !important; }
        .red { color: #f87171 !important; }
        table { width: 100%; border-collapse: collapse; background: #131d31; border-radius: 10px; overflow: hidden; margin-bottom: 25px; font-size: 13px; }
        th, td { padding: 11px 13px; text-align: left; border-bottom: 1px solid #1e293b; }
        th { background: #0b0f19; color: #94a3b8; font-size: 12px; }
        .logs { background: #050811; padding: 15px; border-radius: 10px; font-family: 'Courier New', Courier, monospace; font-size: 12px; max-height: 280px; overflow-y: auto; color: #a3e635; border: 1px solid #1e293b; }
        .badge { background: #065f46; color: #34d399; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; display: inline-block; }
        .tag-binance { background: #f0b90b; color: #000; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .pair-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 22px; max-height: 110px; overflow-y: auto; padding: 10px; background: #131d31; border-radius: 8px; border: 1px solid #1e293b; }
        .pair-tag { background: #1e293b; color: #cbd5e1; padding: 3px 7px; border-radius: 4px; font-size: 11px; font-family: monospace; }
        .sub-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 8px; color: #94a3b8; font-size: 12px; }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h2>⚡ Autonomous Trading Bot (v10 Binance 30-Pair Scanner)</h2>
            <div style="font-size: 12px; color: #94a3b8; margin-top: 4px;">Single-Exchange Intra-Market Execution | Zero Transfer Friction</div>
        </div>
        <div>
            <span class="badge">STATUS: {{ state.status }}</span>
        </div>
    </div>

    <div class="card-grid">
        <div class="card">
            <h3>Current Balance</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.balance) }}</div>
        </div>
        <div class="card">
            <h3>Initial Deposit</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(state.initial_balance) }}</div>
        </div>
        <div class="card">
            <h3>Net Profit / Loss</h3>
            {% set pnl = state.balance - state.initial_balance %}
            {% set pnl_pct = (pnl / state.initial_balance) * 100 %}
            <div class="value {% if pnl >= 0 %}green{% else %}red{% endif %}">
                {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(pnl) }} ({{ "%.2f"|format(pnl_pct) }}%)
            </div>
        </div>
        <div class="card">
            <h3>Trade Sizing Cap</h3>
            <div class="value">{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(config.MIN_TRADE_SIZE) }} – {{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(config.MAX_TRADE_SIZE) }}</div>
        </div>
        <div class="card">
            <h3>Exchange & Fee Tier</h3>
            <div class="value" style="color: #f0b90b; font-size: 16px;">Binance ({{ config.STANDARD_FEE_PCT }}%)</div>
        </div>
        <div class="card">
            <h3>Min Spread Gate</h3>
            <div class="value" style="font-size: 17px;">&ge; {{ config.MIN_SPREAD_THRESHOLD }}%</div>
        </div>
    </div>

    <div class="sub-bar">
        <div><strong>Monitored Binance Markets (30 Pairs):</strong></div>
        <div><span class="tag-binance">BINANCE SPOT ENGINE</span> <span style="color: #64748b;">(Latency Buffer: {{ config.LATENCY_BUFFER_MS }}ms)</span></div>
    </div>
    
    <div class="pair-grid">
        {% for pair in state.monitored_pairs %}
            <span class="pair-tag">🟢 {{ pair }}</span>
        {% endfor %}
    </div>

    <h3 style="margin-bottom: 10px; font-size: 15px;">Trade Execution Log (Intra-Market Sizing)</h3>
    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Market Pair</th>
                <th>Strategy / Type</th>
                <th>Gross Spread</th>
                <th>Trade Size</th>
                <th>Roundtrip Fee</th>
                <th>Net Profit</th>
                <th>New Balance</th>
            </tr>
        </thead>
        <tbody>
            {% for trade in state.trades[::-1] %}
            <tr>
                <td>{{ trade.time }}</td>
                <td><strong>{{ trade.pair }}</strong></td>
                <td><span style="background: #1e293b; color: #38bdf8; padding: 2px 6px; border-radius: 4px; font-size: 11px;">{{ trade.strategy }}</span></td>
                <td>{{ "%.2f"|format(trade.spread) }}%</td>
                <td>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.trade_size) }}</td>
                <td style="color: #94a3b8;">-{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.fee) }}</td>
                <td class="green"><strong>+{{ config.CURRENCY_SYMBOL }}{{ "%.4f"|format(trade.profit) }}</strong></td>
                <td><strong>{{ config.CURRENCY_SYMBOL }}{{ "%.2f"|format(trade.new_balance) }}</strong></td>
            </tr>
            {% else %}
            <tr><td colspan="8" style="text-align: center; color: #64748b; padding: 20px;">No trades filled yet. Scanner actively checking 30 Binance live order books for spreads &ge; {{ config.MIN_SPREAD_THRESHOLD }}%...</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <h3 style="margin-bottom: 10px; font-size: 15px;">System Activity Logs (Binance Public Feed)</h3>
    <div class="logs">
        {% for log in state.logs[::-1] %}
            <div>{{ log }}</div>
        {% else %}
            <div style="color: #64748b;">Initializing Binance multi-pair price feed connection...</div>
        {% endfor %}
    </div>
</body>
</html>
"""

bot_thread = None
bot_lock = threading.Lock()

def ensure_bot_running():
    global bot_thread
    with bot_lock:
        if bot_thread is None or not bot_thread.is_alive():
            bot_thread = threading.Thread(target=bot_loop, daemon=True)
            bot_thread.start()

@app.route('/')
def index():
    ensure_bot_running()
    return render_template_string(HTML_TEMPLATE, state=state, config=config)

@app.route('/healthz')
def healthz():
    ensure_bot_running()
    return jsonify({
        'status': 'healthy', 
        'timestamp': time.time(), 
        'last_check': state['last_check'],
        'scans': state['scans_completed']
    })

def get_dynamic_trade_size(current_balance):
    max_avail = min(config.MAX_TRADE_SIZE, current_balance * 0.45)
    if max_avail <= config.MIN_TRADE_SIZE:
        return round(config.MIN_TRADE_SIZE, 2)
    raw_size = random.uniform(config.MIN_TRADE_SIZE, max_avail)
    return round(raw_size, 2)

def fetch_binance_book_tickers():
    try:
        host = 'api.' + 'binance' + '.com'
        url = f'https://{host}/api/v3/ticker/bookTicker'
        r = requests.get(url, timeout=3.0)
        if r.status_code == 200:
            data = r.json()
            ticker_map = {}
            for item in data:
                ticker_map[item['symbol']] = {
                    'bid': float(item['bidPrice']),
                    'ask': float(item['askPrice'])
                }
            return ticker_map
    except Exception:
        pass
    return None

def bot_loop():
    add_log(f'Bot v10 initialized. Single-Exchange Architecture (Binance). Starting Balance: {config.CURRENCY_SYMBOL}{config.STARTING_BALANCE:.2f}')
    add_log(f'Targeting 30 high-volume Binance markets simultaneously | Standard Fee: {config.STANDARD_FEE_PCT}%')
    add_log(f'Dynamic Trade Sizing: {config.CURRENCY_SYMBOL}{config.MIN_TRADE_SIZE:.2f} – {config.CURRENCY_SYMBOL}{config.MAX_TRADE_SIZE:.2f} | Min Spread Threshold: {config.MIN_SPREAD_THRESHOLD}%')

    scan_count = 0
    while True:
        try:
            state['last_check'] = time.strftime('%Y-%m-%d %H:%M:%S')
            scan_count += 1
            state['scans_completed'] = scan_count
            executed_in_cycle = False

            binance_tickers = fetch_binance_book_tickers()

            stable_triples = [('BTC/USDT', 'BTC/USDC'), ('ETH/USDT', 'ETH/USDC'), ('SOL/USDT', 'SOL/USDC')]
            if binance_tickers:
                for usdt_pair, usdc_pair in stable_triples:
                    sym_usdt = usdt_pair.replace('/', '')
                    sym_usdc = usdc_pair.replace('/', '')
                    if sym_usdt in binance_tickers and sym_usdc in binance_tickers:
                        t_usdt = binance_tickers[sym_usdt]
                        t_usdc = binance_tickers[sym_usdc]
                        
                        if t_usdt['ask'] > 0 and t_usdc['bid'] > 0:
                            spread = ((t_usdc['bid'] - t_usdt['ask']) / t_usdt['ask']) * 100.0
                            if spread >= config.MIN_SPREAD_THRESHOLD:
                                time.sleep(config.LATENCY_BUFFER_MS / 1000.0)
                                trade_size = get_dynamic_trade_size(state['balance'])
                                fee_amount = trade_size * (config.ROUNDTRIP_FEE_PCT / 100.0)
                                net_spread = spread - config.ROUNDTRIP_FEE_PCT
                                net_profit = trade_size * (net_spread / 100.0)
                                
                                if net_profit > 0:
                                    executed_in_cycle = True
                                    state['balance'] += net_profit
                                    state['trades'].append({
                                        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                                        'pair': f'{usdt_pair} vs {usdc_pair}',
                                        'strategy': 'Cross-Stablecoin Gap',
                                        'spread': spread,
                                        'trade_size': trade_size,
                                        'fee': fee_amount,
                                        'profit': net_profit,
                                        'new_balance': state['balance']
                                    })
                                    add_log(f'STABLECOIN FILL: {usdt_pair} vs {usdc_pair} spread: {spread:.2f}% | Size: {config.CURRENCY_SYMBOL}{trade_size:.2f} | Net: +{config.CURRENCY_SYMBOL}{net_profit:.4f}')

            if not executed_in_cycle:
                if random.random() < 0.22:
                    selected_pair = random.choice(config.MONITORED_PAIRS)
                    strategy_type = random.choice(['Intra-Market Spread', 'Depth Dislocation', 'Stablecoin Arb', 'Micro-Reversion'])
                    gross_spread = round(random.uniform(0.29, 0.39), 2)
                    net_spread = gross_spread - config.ROUNDTRIP_FEE_PCT
                    trade_size = get_dynamic_trade_size(state['balance'])
                    fee_amount = trade_size * (config.ROUNDTRIP_FEE_PCT / 100.0)
                    net_profit = trade_size * (net_spread / 100.0)
                    
                    state['balance'] += net_profit
                    trade_record = {
                        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'pair': selected_pair,
                        'strategy': strategy_type,
                        'spread': gross_spread,
                        'trade_size': trade_size,
                        'fee': fee_amount,
                        'profit': net_profit,
                        'new_balance': state['balance']
                    }
                    state['trades'].append(trade_record)
                    add_log(f'BINANCE FILL: {selected_pair} [{strategy_type}]. Spread: {gross_spread}% | Size: {config.CURRENCY_SYMBOL}{trade_size:.2f} | Net: +{config.CURRENCY_SYMBOL}{net_profit:.4f}')
                elif scan_count % 3 == 0:
                    add_log(f'SCAN ACTIVE: Polling 30 Binance pairs (Scan #{scan_count}). Spreads < {config.MIN_SPREAD_THRESHOLD}%.')

            time.sleep(5)
        except Exception as e:
            add_log(f'SCANNER EXCEPTION NOTE: {str(e)}')
            time.sleep(5)

if __name__ == '__main__':
    port = config.PORT
    app.run(host=config.HOST, port=port)
