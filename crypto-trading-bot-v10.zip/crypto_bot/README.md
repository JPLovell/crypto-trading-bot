# Autonomous Crypto Trading Bot (v10 Binance 30-Pair Scanner)

## Architecture Overview
- **Execution Model:** Single-Exchange Intra-Market Architecture (Binance Spot)
- **Account Sizing:** Calibrated for a single £50 starting deposit (~5 USDT).
- **Zero Transfer Friction:** All scanning and execution occur within Binance order books, completely eliminating cross-exchange rebalancing, withdrawal fees, and inventory lock.
- **Monitored Markets:** 30 high-volume Binance coin pairs and stablecoin order books.
- **Dynamic Trade Sizing:** £10.00 to £25.00 per trade (strictly maintaining >=50% liquidity buffer in cash).
- **Fee Tier:** 0.10% standard spot fee (0.20% round-trip) with spread gate >= 0.28%.

## Deployment on Render
1. Upload this repository or drag & drop the files to your GitHub account.
2. Link the repository to Render as a Web Service.
3. Build Command: 
4. Start Command: 
5. Access your live web dashboard via the Render service URL.
