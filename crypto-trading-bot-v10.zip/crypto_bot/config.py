import os

# Account & Capital Settings (Single-Exchange Architecture)
STARTING_BALANCE = 50.0       # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0         # £10 minimum trade size (comfortably clears Binance $5-$10 min order)
MAX_TRADE_SIZE = 25.0         # £25 max trade size cap (preserves >= 50% liquidity buffer)
CURRENCY_SYMBOL = "£"

# Single-Exchange Execution Parameters (Binance Intra-Market)
PRIMARY_EXCHANGE = "Binance"
STANDARD_FEE_PCT = 0.10       # Binance standard spot fee per trade (0.10%)
ROUNDTRIP_FEE_PCT = 0.20      # Round-trip buy + sell fee (0.20%)
BNB_DISCOUNT_FEE_PCT = 0.075  # Optional BNB discounted fee (0.075%)
MIN_SPREAD_THRESHOLD = 0.28   # Minimum spread needed to trigger trade (0.28%)
LATENCY_BUFFER_MS = 150       # Realistic order-matching latency buffer (150ms)

# 30 High-Volume Binance Markets Monitored Simultaneously
MONITORED_PAIRS = [
    # Top Tier Layer-1 & Mega-Caps
    "BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT", 
    "ADA/USDT", "AVAX/USDT", "DOT/USDT", "NEAR/USDT", "SUI/USDT",
    # High-Momentum Alts & DeFi
    "LINK/USDT", "DOGE/USDT", "PEPE/USDT", "SHIB/USDT", "LTC/USDT",
    "ARB/USDT", "OP/USDT", "INJ/USDT", "TIA/USDT", "FET/USDT",
    "RENDER/USDT", "ATOM/USDT", "UNI/USDT", "APT/USDT", "FIL/USDT",
    "ICP/USDT", "FTM/USDT",
    # Cross-Stablecoin Pairs (USDT vs USDC on Binance)
    "BTC/USDC", "ETH/USDC", "SOL/USDC"
]

# Web Server & Deployment Settings
PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
