import os

# Account & Capital Settings (Kraken Pro Live Architecture)
STARTING_BALANCE = 50.0          # Initial deposit (£50.00)
MIN_TRADE_SIZE = 10.0            # £10 minimum trade size
MAX_TRADE_SIZE = 25.0            # £25 max trade size cap (preserves >= 50% cash liquidity reserve)
MAX_WORKING_CAPITAL = 50.0       # Risk Ring-Fence Cap (£50 max active capital)
CURRENCY_SYMBOL = "£"

# Kraken Pro Fee & Execution Parameters
PRIMARY_EXCHANGE = "Kraken Pro"
TAKER_FEE_PCT = 0.40             # Kraken Pro standard entry taker fee per trade (0.40%)
ROUNDTRIP_FEE_PCT = 0.80         # Round-trip buy taker + sell taker fee (0.80%)
MIN_SPREAD_THRESHOLD = 0.88      # Minimum spread required to trigger order (0.88% covers 0.80% fee + 0.08% profit floor)
MIN_DEPTH_USD = 50.0             # 0 top-of-book depth filter to guarantee zero slippage
LATENCY_BUFFER_MS = 25           # WebSocket execution latency buffer (25ms)

# Live Environment Variables & API Credentials
KRAKEN_API_KEY = os.environ.get("KRAKEN_API_KEY", "")
KRAKEN_API_SECRET = os.environ.get("KRAKEN_API_SECRET", "")
LIVE_TRADING_ENABLED = os.environ.get("LIVE_TRADING_ENABLED", "false").lower() in ["true", "1", "yes"]

# Live Market Reality Settings (Simulated vs Live Routing)
SIMULATE_REALISTIC_FILLS = not (LIVE_TRADING_ENABLED and bool(KRAKEN_API_KEY) and bool(KRAKEN_API_SECRET))
FILL_RATE_MEGA_CAP = 0.28        # ~28% fill rate on BTC, ETH, SOL on Kraken
FILL_RATE_VOLATILE_ALT = 0.62    # ~62% fill rate on mid-cap alts & direct GBP pairs
FILL_RATE_STABLECOIN = 0.40      # ~40% fill rate on USDT/GBP, USDC/GBP, BTC/USDC

# 30 High-Opportunity Kraken Markets Monitored Simultaneously (Direct GBP & Top Altcoins)
MONITORED_PAIRS = [
    "BTC/GBP", "ETH/GBP", "SOL/GBP", "XRP/GBP", "ADA/GBP", 
    "DOT/GBP", "LINK/GBP", "AVAX/GBP", "NEAR/GBP", "DOGE/GBP",
    "LTC/GBP", "ATOM/GBP", "FIL/GBP", "UNI/GBP", "USDT/GBP",
    "NEAR/USDT", "SOL/USDT", "FIL/USDT", "UNI/USDT", "INJ/USDT",
    "TIA/USDT", "RENDER/USDT", "SUI/USDT", "PEPE/USDT", "FET/USDT",
    "ARB/USDT", "OP/USDT", "DOT/USDT", "LINK/USDT", "BTC/USDT"
]

# Web Server & Deployment Settings
PORT = int(os.environ.get("PORT", 8080))
HOST = "0.0.0.0"
