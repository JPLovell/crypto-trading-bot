# Autonomous Crypto Trading Bot (v14 Kraken Pro Live Execution Engine)

## Overview
- **Exchange:** Kraken Pro (UK FCA Compliant)
- **Live API Integration:** Real-Time Private API Order Routing
- **Fiat Support:** Direct Native GBP (£) Trading Pairs
- **Risk Limits:** Strict £10 - £25 Per-Trade Sizing Cap
- **Safety Gates:** Immediate-or-Cancel (IOC) Execution + 0 Top-of-Book Depth Filter

## Deploying to Render
1. Extract .
2. Push the files to your GitHub repository connected to Render.
3. Build Command: 
4. Set Environment Variables on Render:
   - 
   - 
   -  = 
5. Click **Manual Deploy** -> **Clear Build Cache & Deploy**.
